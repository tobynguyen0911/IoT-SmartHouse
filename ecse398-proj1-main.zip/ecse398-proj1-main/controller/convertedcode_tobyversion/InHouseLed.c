#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"

#define LED_PIN 2
#define PIR_PIN 3

const static char *TAG = "PIR_LED";

void pir_task(void *pvParameters) {
    while (1) {
        if (gpio_get_level(PIR_PIN) == 0) { // If PIR sensor detects motion
            gpio_set_level(LED_PIN, 1); // Turn on LED
            ESP_LOGI(TAG, "Movement detected");
            vTaskDelay(10000 / portTICK_PERIOD_MS); // Delay for 10 seconds (adjust as needed)
        } else {
            gpio_set_level(LED_PIN, 0); // Turn off LED if no motion detected
            ESP_LOGI(TAG, "No movement detected");
            vTaskDelay(100 / portTICK_PERIOD_MS); // Short delay to debounce the PIR sensor output
        }
    }
}

void app_main() {
    gpio_pad_select_gpio(LED_PIN);
    gpio_set_direction(LED_PIN, GPIO_MODE_OUTPUT);

    gpio_pad_select_gpio(PIR_PIN);
    gpio_set_direction(PIR_PIN, GPIO_MODE_INPUT);

    xTaskCreate(pir_task, "pir_task", 2048, NULL, 10, NULL);
}
