#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_system.h"

#define TRIG_PIN GPIO_NUM_12
#define ECHO_PIN GPIO_NUM_13
#define SERVO_PIN GPIO_NUM_26

#define TAG "WINDOW_CONTROL"

TaskHandle_t window_task_handle = NULL;

void set_servo_angle(int angle) {
    // Function to set the servo angle
    myservo_write(SERVO_PIN, angle); // Assuming you have a function like myservo_write in your library
}

float get_distance() {
    // Function to get distance from ultrasonic sensor
    digitalWrite(TRIG_PIN, LOW);
    ets_delay_us(2);
    digitalWrite(TRIG_PIN, HIGH);
    ets_delay_us(10);
    digitalWrite(TRIG_PIN, LOW);
    int duration = pulseIn(ECHO_PIN, HIGH);
    int distance = duration / 58;
    return distance;
}

void window_control_task(void *pvParameters) {
    float distance;

    while (1) {
        distance = get_distance();

        // Open or close the window based on distance
        if (distance >= 2 && distance <= 7) {
            ESP_LOGI(TAG, "Opening window");
            set_servo_angle(50); // Open the window
        } else {
            ESP_LOGI(TAG, "Closing window");
            set_servo_angle(180); // Close the window
        }

        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

void app_main() {
    // Initialize GPIO
    gpio_config_t io_conf;
    io_conf.intr_type = GPIO_PIN_INTR_DISABLE;
    io_conf.mode = GPIO_MODE_OUTPUT;
    io_conf.pin_bit_mask = (1ULL << TRIG_PIN) | (1ULL << ECHO_PIN);
    io_conf.pull_down_en = 0;
    io_conf.pull_up_en = 0;
    gpio_config(&io_conf);

    // Create window control task
    xTaskCreate(window_control_task, "window_control_task", 4096, NULL, 5, &window_task_handle);
}
