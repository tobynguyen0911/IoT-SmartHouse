#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_system.h"

#define STEAM_PIN 35            // Steam sensor pin
#define BUZZER_PIN 16           // Buzzer pin
#define PIR_PIN 23              // PIR motion sensor pin

#define STEAM_THRESHOLD_LOW 800
#define STEAM_THRESHOLD_HIGH 4000

static const char *TAG = "SENSOR_TASK";

void setup_peripherals() {
    // Initialize serial communication for debugging
    esp_log_level_set(TAG, ESP_LOG_INFO); // Set log level to INFO
    gpio_pad_select_gpio(STEAM_PIN);
    gpio_set_direction(STEAM_PIN, GPIO_MODE_INPUT);
    gpio_pad_select_gpio(BUZZER_PIN);
    gpio_set_direction(BUZZER_PIN, GPIO_MODE_OUTPUT);
    gpio_pad_select_gpio(PIR_PIN);
    gpio_set_direction(PIR_PIN, GPIO_MODE_INPUT);
}

void sensor_task(void *pvParameters) {
    while (1) {
        // Read the value from the steam sensor
        int steamValue = adc1_get_raw(ADC1_CHANNEL_6); // Adjust ADC channel according to your setup
        ESP_LOGI(TAG, "Steam Value: %d", steamValue);
        
        // Read the value from the PIR motion sensor
        int pirValue = gpio_get_level(PIR_PIN);
        
        // If both motion and steam detected, play unique sound
        if (pirValue && steamValue >= STEAM_THRESHOLD_LOW) {
            unique_sound();
        } 
        // If only motion detected
        if (pirValue) {
            ESP_LOGI(TAG, "Someone detected");
            for(int i = 200; i <= 1000; i+= 10) {
            tone(BUZZER_PIN,i);
            vTaskDelay(pdMS_TO_TICKS(10));
            }
        } 
        
        // Determine whether the detected value is within thresholds
        if (steamValue >= STEAM_THRESHOLD_LOW && steamValue < 2000) {
            // Execute for 3 times
            for (int i = 0; i < 3; i++) {
                tone(BUZZER_PIN, 200);
                vTaskDelay(pdMS_TO_TICKS(100));
                noTone(BUZZER_PIN);
                vTaskDelay(pdMS_TO_TICKS(100));
            }
        } else if (steamValue >= 2000 && steamValue <= 4000) {
            for (int i = 0; i < 3; i++) {
                tone(BUZZER_PIN, 400);
                vTaskDelay(pdMS_TO_TICKS(100));
                noTone(BUZZER_PIN);
                vTaskDelay(pdMS_TO_TICKS(100));
            }
        } else if (steamValue > 4000) {
            for (int i = 0; i < 3; i++) {
                tone(BUZZER_PIN, 600);
                vTaskDelay(pdMS_TO_TICKS(100));
                noTone(BUZZER_PIN);
                vTaskDelay(pdMS_TO_TICKS(100));
            }
        }
        noTone(BUZZER_PIN);
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

void unique_sound() {
    for (int i = 300; i <= 2000; i += 15) {
        gpio_set_level(BUZZER_PIN, i);
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

void app_main() {
    setup_peripherals();
    xTaskCreate(sensor_task, "sensor_task", 4096, NULL, 5, NULL);
}
