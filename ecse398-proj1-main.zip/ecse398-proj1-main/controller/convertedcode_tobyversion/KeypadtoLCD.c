#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "string.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/sysmacros.h>
#include <linux/i2c-dev.h>
#include <errno.h>

#define TAG "KEYPAD_LCD"

#define ROWS 4
#define COLS 3

char keys[ROWS][COLS] = {
    {'1','2','3'},
    {'4','5','6'},
    {'7','8','9'},
    {'*','0','#'}
};

int rowPins[ROWS] = {4, 5, 6, 7};
int colPins[COLS] = {8, 10, 9};

QueueHandle_t keypadQueue;
TaskHandle_t keypadTaskHandle;

// Function prototypes
char readKeypad();
void lcdPrint(const char* message);
void initKeypad();
void initLCD();
char getKeyFromKeypad();
void keypadTask(void *pvParameters);

void app_main() {
    initKeypad();
    initLCD();

    keypadQueue = xQueueCreate(5, sizeof(char));
    xTaskCreate(keypadTask, "Keypad Task", 2048, NULL, 2, &keypadTaskHandle);
}

void initKeypad() {
    // Initialize keypad pins
    for (int i = 0; i < ROWS; i++) {
        gpio_set_direction(rowPins[i], GPIO_MODE_INPUT);
        gpio_set_pull_mode(rowPins[i], GPIO_PULLUP_ONLY);
    }
    for (int j = 0; j < COLS; j++) {
        gpio_set_direction(colPins[j], GPIO_MODE_OUTPUT);
        gpio_set_level(colPins[j], 1);
    }
}

void initLCD() {
    // Initialize LCD
    int fd;
    char *filename = (char*)"/dev/i2c-0";
    int addr = 0x27; // Address of LCD
    if ((fd = open(filename, O_RDWR)) < 0) {
        printf("Failed to open i2c port\n");
        exit(1);
    }
    if (ioctl(fd, I2C_SLAVE, addr) < 0) {
        printf("Unable to get bus access to talk to slave\n");
        exit(1);
    }
    // LCD init sequence
    write(fd, "\x03", 1);
    write(fd, "\x03", 1);
    write(fd, "\x03", 1);
    write(fd, "\x02", 1);
    write(fd, "\x28", 1);
    write(fd, "\x0c", 1);
    write(fd, "\x01", 1);
    write(fd, "\x06", 1);
}

void lcdPrint(const char* message) {
    // Print a message on the LCD
    int fd;
    char *filename = (char*)"/dev/i2c-0";
    int addr = 0x27; // Address of LCD
    if ((fd = open(filename, O_RDWR)) < 0) {
        printf("Failed to open i2c port\n");
        exit(1);
    }
    if (ioctl(fd, I2C_SLAVE, addr) < 0) {
        printf("Unable to get bus access to talk to slave\n");
        exit(1);
    }
    write(fd, "\x01", 1); // Clear screen
    usleep(2000);
    write(fd, "\x02", 1); // Return home
    usleep(2000);
    write(fd, message, strlen(message)); // Write message
}

char getKeyFromKeypad() {
    // Function to get a key from the keypad
    char key = '\0';

    // Scan keypad rows
    for (int i = 0; i < ROWS; i++) {
        gpio_set_level(colPins[i], 0);
        for (int j = 0; j < COLS; j++) {
            if (gpio_get_level(rowPins[j]) == 0) {
                key = keys[j][i];
                break;
            }
        }
        gpio_set_level(colPins[i], 1);
        if (key != '\0') {
            break;
        }
    }
    return key;
}

void keypadTask(void *pvParameters) {
    char key;
    char password[] = "1234"; // Define your password
    char inputPassword[5] = "";
    int inputIndex = 0;

    for (;;) {
        key = getKeyFromKeypad();
        if (key != '\0') {
            if (key == '#') {
                if (strcmp(password, inputPassword) == 0) {
                    lcdPrint("Correct Key");
                    // Call function to unlock or perform desired action
                } else {
                    lcdPrint("Incorrect Key");
                }
                inputIndex = 0;
                memset(inputPassword, 0, sizeof(inputPassword)); // Clear input password
            } else if (key == '*') {
                inputIndex = 0;
                memset(inputPassword, 0, sizeof(inputPassword)); // Clear input password
                lcdPrint("Insert Password");
            } else {
                if (inputIndex < 4) {
                    inputPassword[inputIndex++] = key;
                    lcdPrint("*"); // Print asterisk on LCD
                }
            }
        }
        vTaskDelay(pdMS_TO_TICKS(100)); // Adjust delay as needed
    }
}
