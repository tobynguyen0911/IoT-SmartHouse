#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"

#define ButtonPin     5   // Define a button pin
#define PhotocecllPin 34  // Define the photoresistor pin
#define LED           27  // Define LED pin

// Structure to hold device state
typedef struct {
    bool ledState; // State of the LED
} device_state_t;

device_state_t device_state; // Global instance of device state

void init_gpio() {
    // Set pin modes
    gpio_set_direction(ButtonPin, GPIO_MODE_INPUT);
    gpio_set_direction(PhotocecllPin, GPIO_MODE_INPUT);
    gpio_set_direction(LED, GPIO_MODE_OUTPUT);
}

void update_led() {
    // Read the value of the photoresistor
    int photoValue = analogRead(PhotocecllPin);

    // Print the photoresistor value
    ESP_LOGI("Photocecll", "Value: %d", photoValue);

    // Determine LED state based on photoresistor value
    if (photoValue >= 1000) {
        // LED turns off when it's bright
        gpio_set_level(LED, 0);
        ESP_LOGI("LED", "OFF");
        device_state.ledState = false;
    } else {
        // LED turns on when it's dark
        gpio_set_level(LED, 1);
        ESP_LOGI("LED", "ON");
        device_state.ledState = true;
    }
}

void button_task(void *pvParameters) {
    while (1) {
        // Check if the button is pressed
        int buttonState = gpio_get_level(ButtonPin);
        if (buttonState == 0) {
            // If the button is pressed, keep the LED on
            gpio_set_level(LED, 1);
            device_state.ledState = true;
        }
        vTaskDelay(100 / portTICK_PERIOD_MS);
    }
}

void app_main() {
    // Initialize serial port and set baud rate to 9600
    ESP_ERROR_CHECK(uart_set_baudrate(UART_NUM_0, 9600));
    ESP_LOGI("APP_MAIN", "Serial initialized.");

    init_gpio(); // Initialize GPIO pins

    // Create button task
    TaskHandle_t button_handle;
    xTaskCreate(button_task, "button_task", 2048, NULL, 10, &button_handle);
    
    // Main loop
    while (1) {
        update_led(); // Update LED based on photoresistor value
        vTaskDelay(100 / portTICK_PERIOD_MS);
    }
}
