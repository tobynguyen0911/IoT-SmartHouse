#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "driver/adc.h"
#include "esp_log.h"
#include "cJSON.h"

#define SHPin 32          // Soil Humidity Sensor Pin
#define WLPin 33          // Water Level Sensor Pin
#define DHT11PIN 17       // DHT11 Sensor Pin
#define RelayPin 25       // Relay Control Pin
#define MotorPin1 19      // Motor Pin 1
#define MotorPin2 18      // Motor Pin 2

// Initialize LCD
LiquidCrystal_I2C lcd(0x27, 16, 2);
// Initialize DHT11 sensor
dht11 DHT11;

// Variables to store previous sensor readings
int prevSHVal = -1;
int prevWLVal = -1;
int prevTemp = -1;
int prevHumidity = -1;

// Task to read sensors and update LCD
void sensor_task(void *pvParameters) {
    while (1) {
        // Read sensor values
        int shVal = analogRead(SHPin); // Soil Humidity
        int wlVal = analogRead(WLPin); // Water Level

        int temp;
        int humidity;

        int chk = DHT11.read(DHT11PIN);
        temp = DHT11.temperature;
        humidity = DHT11.humidity;

        // Display sensor readings on LCD
        lcd.setCursor(0, 0);
        if (prevSHVal != shVal) {
            lcd.print("SH:"); // Soil Humidity
            lcd.setCursor(3, 0);
            lcd.print(shVal);
            prevSHVal = shVal;
        }

        lcd.setCursor(9, 0);
        if (prevTemp != temp) {
            lcd.print("T:"); // Temperature
            lcd.setCursor(12, 0);
            lcd.print(temp);
            prevTemp = temp;
        }

        lcd.setCursor(0, 1);
        if (prevWLVal != wlVal) {
            lcd.print("WL:"); // Water Level
            lcd.setCursor(4, 1);
            lcd.print(wlVal);
            prevWLVal = wlVal;
        }

        lcd.setCursor(9, 1);
        if (prevHumidity != humidity) {
            lcd.print("H:"); // Humidity
            lcd.setCursor(12, 1);
            lcd.print(humidity);
            prevHumidity = humidity;
        }

        vTaskDelay(1000 / portTICK_PERIOD_MS); // Delay between sensor readings
    }
}

// Task to handle API requests
void api_task(void *pvParameters) {
    while (1) {
        // Handle API requests here
        // For example, respond with JSON containing sensor readings

        // Create JSON object
        cJSON *json_root = cJSON_CreateObject();
        cJSON_AddNumberToObject(json_root, "soil_humidity", prevSHVal);
        cJSON_AddNumberToObject(json_root, "water_level", prevWLVal);
        cJSON_AddNumberToObject(json_root, "temperature", prevTemp);
        cJSON_AddNumberToObject(json_root, "humidity", prevHumidity);

        // Convert JSON object to string
        char *json_str = cJSON_Print(json_root);
        cJSON_Delete(json_root);

        // Send JSON string to web app or mobile app (pseudocode)
        //send_json_to_app(json_str);

        free(json_str); // Free memory allocated by cJSON_Print

        vTaskDelay(5000 / portTICK_PERIOD_MS); // Delay between API responses
    }
}

void app_main() {
    // Set pin modes
    pinMode(SHPin, INPUT);
    pinMode(WLPin, INPUT);
    pinMode(RelayPin, OUTPUT);
    pinMode(MotorPin1, OUTPUT);
    pinMode(MotorPin2, OUTPUT);

    // Initialize LCD
    lcd.init();
    lcd.backlight();
    lcd.clear();

    // Start tasks to read sensors and handle API requests
    xTaskCreate(sensor_task, "sensor_task", 2048, NULL, 10, NULL);
    xTaskCreate(api_task, "api_task", 2048, NULL, 10, NULL);
}
