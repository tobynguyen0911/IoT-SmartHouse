#include "esp_adc/adc_oneshot.h"
adc_oneshot_unit_handle_t adc1_handle;
int adc_setup = false;