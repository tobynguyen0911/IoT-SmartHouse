#include "device_utils.h"
driver_t * gen_LCD_driver(int pins[]);