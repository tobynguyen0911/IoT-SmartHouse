#include "device_utils.h"

driver_t * gen_led_driver(int pins[]);
driver_t * gen_led_btn_driver(int pins[]);