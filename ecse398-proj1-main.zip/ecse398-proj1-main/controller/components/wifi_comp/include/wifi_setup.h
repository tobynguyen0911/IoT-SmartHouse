//#include "wifi_setup.c"

void wifi_station_init(void);
