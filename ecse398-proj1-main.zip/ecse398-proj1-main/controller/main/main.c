#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "sdkconfig.h"
#include <string.h>
#include "esp_system.h"
#include "esp_wifi.h"
#include "nvs_flash.h"

#include "wifi_setup.h"
#include "server.h"
#include "device_utils.h"
#include "led_driver.h"
#include "esp_http_client.h"
#include "esp_mac.h"
#include "sensors.h"
#include "LCD.h"

#include "cJSON.h"


#define led_out_pin 3
#define btn_in_pin 2

#define STACK_SIZE 204810

#define TEST_ESP

int local_ids = 0;


/* Overall architecture
 *
 * Main app:
 *   Connect to the network (just wifi at first)
 *   Call device drivers' setup functions
 *   Start device tasks
 *   Loop:
 *     Check for state changes (and report to server)
 *     Check server for actions
 * Device app:
 *   Can do anything
 *   Read/write from GPIO
 *   Check IPC for commands from main app
 */


char * send_device_update(char * request_body)
{
    return http_rest("/api/devices", HTTP_METHOD_POST, request_body, strlen(request_body));
}

cJSON * constructJSONStringFromDriver(driver_t * driver)
{
    cJSON * state_element = driver->definition->state->device_data;
    cJSON * root = cJSON_CreateObject();
    if (driver->definition->device_id != NULL) {
        cJSON * dev_id = cJSON_CreateStringReference(driver->definition->device_id);
        cJSON_AddItemToObject(root, "device_id", dev_id);
    }
    cJSON_AddNumberToObject(root, "local_id", (double) driver->definition->device_local_id);
    cJSON_AddNumberToObject(root, "driver_id", (double) driver->driver->driver_id);
    cJSON_AddItemToObject(root, "state", state_element);

    return root;
}

cJSON * constructControllerForStartup(int controller_id, int n_drivers, driver_t * drivers[])
{
    cJSON * root = cJSON_CreateObject();
    cJSON * id = cJSON_CreateNumber((double) controller_id);
    cJSON_AddItemToObject(root, "local_id", id);
    
    cJSON * device_arr = cJSON_CreateArray();
    for(int i = 0; i < n_drivers; i++)
    {
        cJSON_AddItemReferenceToArray(device_arr, constructJSONStringFromDriver(drivers[i]));
    }

    cJSON_AddItemToObject(root, "devices", device_arr);
    return root;
}


void app_main(void)
{

    printf("MAC:\n");
    unsigned char mac[6] = {0};
    esp_efuse_mac_get_default(mac);
    esp_read_mac(mac, ESP_MAC_WIFI_STA);
    printf("%02X:%02X:%02X:%02X:%02X:%02X\n", mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);


    gpio_install_isr_service(0);

    // Initiate nvs
    // This is necessary for the wifi driver

    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
      ESP_ERROR_CHECK(nvs_flash_erase());
      ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    wifi_station_init();

    //printf("Sending request...");

    //http_rest_with_url();

    //char * endpoint = "/controllers";

    //char * response = http_rest(endpoint, NULL, NULL, 0);

    //printf("response %s", response);
    //free(response);

    #ifdef ESP_2
    printf("Starting esp 3\n");
    CONFIG FOR TEST ESP (SHOULD BE IFDEFs LATER)
    
    int controller_id = 2;

    int n_drivers = 1;
    driver_t * drivers[n_drivers];


    int * pins = malloc(sizeof(int) * 2);
    pins[0] = 2;
    pins[1] = 3;

    driver_t * led_driver = gen_led_btn_driver(pins);
    drivers[0] = led_driver;

    #endif

    #ifdef ESP_3
    printf("Starting esp 3\n");
    //CONFIG FOR ESP 1

    int controller_id = 3;

    int n_drivers = 3;
    driver_t * drivers[n_drivers];

    int * pins = malloc(sizeof(int) * 3);
    
    pins[0] = 1;
    driver_t * driver1 = gen_smoke_driver(pins);
    drivers[0] = driver1;

    pins[1] = 2;
    drivers[1] = gen_led_driver(&(pins[1]));

    pins[2] = 6;
    drivers[2] = gen_led_driver(&(pins[2]));
    #endif

    #ifdef ESP_1
    printf("Starting esp plus\n");
    //CONFIG FOR ESP PLUS
    int controller_id = 1;
    
    int n_drivers = 8;
    driver_t * drivers[n_drivers];

    int n_pins = 9;
    int * pins = malloc(sizeof(int) * n_pins);

    
    pins[0] = 19;
    drivers[0] = gen_fan_driver(pins);

    pins[1] = 5;
    pins[2] = 27;
    drivers[1] = gen_led_btn_driver(&(pins[1]));

    pins[3] = 34;
    drivers[2] = gen_photo_driver(&(pins[3]));

    pins[4] = 35;
    drivers[3] = gen_steam_driver(&(pins[4]));

    pins[5] = 33;
    drivers[4] = gen_water_driver(&(pins[5]));

    pins[6] = 32;
    drivers[5] = gen_soil_driver(&(pins[6]));

    pins[7] = 25;
    drivers[6] = gen_pump_btn_driver(&(pins[7]));

    pins[8] = 17;
    drivers[7] = gen_dht_driver(&(pins[8]));
    #endif

    #ifdef TEST_ESP
    printf("Starting test esp\n");
    //TEST CONF
    int controller_id = 1;
    
    int n_drivers = 1;
    driver_t * drivers[n_drivers];

    int n_pins = 2;
    int * pins = malloc(sizeof(int) * n_pins);

    pins[0] = 21;
    pins[1] = 22;
    drivers[0] = gen_LCD_driver(pins);
    #endif

    // END DEVICE DEFINITION

    // Run init funcs
    for(int i = 0; i < n_drivers; i++)
    {
        drivers[i]->driver->init_func(drivers[i]->definition->pins, drivers[i]->definition);
    }

    printf("\nconstructing");

    cJSON * startup_controller = constructControllerForStartup(controller_id, n_drivers, drivers);

    char * r = cJSON_Print(startup_controller);
    
    cJSON_Delete(startup_controller);

    char * response = http_rest("/api/controllers", HTTP_METHOD_POST, r, strlen(r));
    free(r);

    cJSON * response_JSON = cJSON_Parse(response);
    free(response);


    for(int i = 0; i < n_drivers; i++)
    {
        cJSON* response_devices = cJSON_GetObjectItem(response_JSON, "devices");
        cJSON * element;
        cJSON_ArrayForEach(element, response_devices) {
            if(drivers[i]->definition->device_local_id == cJSON_GetObjectItem(element, "local_id")->valueint)
            {
                char * dev_id = cJSON_GetObjectItem(element, "device_id")->valuestring;
                printf("\n%s\n", dev_id);
                char * new_id = (char *) malloc(strlen(dev_id) + 1);
                strcpy(new_id, dev_id);
                drivers[i]->definition->device_id = new_id;
                printf("\n%s\n", drivers[i]->definition->device_id);
            }
        }
    }

    cJSON_Delete(response_JSON);

    // Start tasks
    for(int i = 0; i < n_drivers; i++)
    {
        drivers[i]->driver->start_task(pins, drivers[i]->definition);
    }

    // Main application loop
    while (1) {
        // For each driver check if updates need to be pushed to server
        for(int i = 0; i < n_drivers; i++)
        {
            // Critical section code not working currently
            // Needs to be fixed but it works without (segfaults are inevitable over time without them though)
            //taskENTER_CRITICAL(drivers[i]->definition->state->dev_spinlock);
            if(drivers[i]->definition->state->updated) {
                printf("Updated state!\n");
                cJSON * request_json_item = constructJSONStringFromDriver(drivers[i]);
                cJSON * request_json = cJSON_CreateArray();
                cJSON_AddItemToArray(request_json, request_json_item);
                char * request = cJSON_Print(request_json);
                printf("\n%s\n", request);
                char * response_str = send_device_update(request);
                cJSON_Delete(request_json);
                free(request);
                // Parse response
                cJSON * response = cJSON_Parse(response_str);
                free(response_str);
                drivers[i]->definition->state->updated = false;
            }

            //taskEXIT_CRITICAL(led_driver_def->state->dev_spinlock);
        }

        
        // Get devices which have functions waiting to be called
        char request_url[80];
        sprintf(request_url, "/api/controllers/%d/events", controller_id);
        char * response_str = http_rest(request_url, HTTP_METHOD_GET, NULL, 0);
        cJSON * response = cJSON_Parse(response_str);
        free(response_str);
        cJSON * action;
        cJSON_ArrayForEach(action, response) {
            // For each device
            for(int i = 0; i < n_drivers; i++)
            {
                printf("Local_id %s, id: %s", drivers[i]->definition->device_id, cJSON_GetStringValue(cJSON_GetObjectItem(action, "device_id")));
                if (strcmp(drivers[i]->definition->device_id, cJSON_GetStringValue(cJSON_GetObjectItem(action, "device_id"))) == 0)
                {
                    printf("Is for device");
                    char * func_name = cJSON_GetStringValue(cJSON_GetObjectItem(action, "name"));
                    printf("\n%s\n", func_name);
                    for(int j = 0; j < drivers[i]->driver->num_functions; j++)
                    {
                        device_func_t * f = drivers[i]->driver->functions[j];

                        printf("func_name = %s : %s\n", func_name, f->func_name);
                        if(strcmp(f->func_name, func_name) == 0)
                        {
                            printf("Calling function");
                            f->func(drivers[i]->definition, cJSON_GetObjectItem(action, "params"));
                        }
                    }
                }
            }
        }
        
	    
        // Check every ~10 ms
        vTaskDelay(250 / portTICK_PERIOD_MS);
    }
}