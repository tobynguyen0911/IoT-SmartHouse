Architecture:

Flask Server --> MongoDB


## How to run

The server can be ran most easily by running "docker compose up" in this directory (/server).

Docker must be installed, any other requirements will be installed during the build process.