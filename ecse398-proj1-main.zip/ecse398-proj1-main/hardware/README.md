# Hardware Designs

All physical layouts, schematics, and drawings should go in this folder